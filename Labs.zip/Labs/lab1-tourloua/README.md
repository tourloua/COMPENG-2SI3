[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/F-MugMJ5)
# Lab 1 - Asymptotic Analysis, OOD Analysis with UML

This is the your first taste of structured C++ OOD project.  Follow the lab manual to navigate around and analyze the project model code.

Student Name: Alexandros Tourloukis

MacID: tourloua
