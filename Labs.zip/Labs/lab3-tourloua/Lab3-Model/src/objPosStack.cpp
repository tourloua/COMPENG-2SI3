#include "objPosStack.h"
#include "objPosDLinkedList.h"

#include <ctime>
#include <cstdlib>
#include <iostream>
using namespace std;

// Available Data Members from objPosStack.h (Must Review)
//
//      objPosList* myList
//      
//  This is the polymorphic list pointer to the underlying List data structure to
//   support all Stack functionalities
//
//  You should use objPosDLinkedList as your main design param


objPosStack::objPosStack()
{
    // Constructor
    //   Instantiate myList as objPosDLinkedList.  You may use objPosArrayList for testing purpose only.
    myList=new objPosDLinkedList;
}


objPosStack::~objPosStack()
{
    // Destructor
    //  Just delete myList (and all otherheap members, if any)
    delete myList;
}


// private helper function
void objPosStack::generateObjects(int count)
{
    // Generate and pushes individual objPos isntances with randomly generated Prefix, Number, and Symbol.
    // The total number of generated instances is capped by input variable **count**.
    
    for (int i=0; i<count;i++)
    {
        char prefix;
    // 1. Generate Prefix A-Z and a-z.  Alphabetic characters only.
        int offset= (rand()%26);
        int upperlower=(rand()%2);
    if (upperlower==0)
    {
        prefix=65+offset;
    }
    else
    {
        prefix=97+offset;
    }
    // 2. Generate Number [0, 99]
    int number=(rand()%100);
    // 3. Leave Symbol as *
    objPos thisPos=objPos();
    thisPos.setPF(prefix);
    thisPos.setNum(number);
    thisPos.setSym('*');
    push(thisPos);
    }

    // Push every randomly generately objPos into the Stack.

}


// private helper function
void objPosStack::sortByTenScoreBS()
{
    // Use BUBBLE SORT to sort all the objPos instances in the Stack in ascending order using the digit of 10
    //  of the **number** field of objPos.

    // You can use the relevant insertion and removal methods from the objPosDLinkedList interface
    //  to complete the sorting operations.

    // Recommendation - use set() and get() - Think about how
    for (int i = 0; i < (myList->getSize()-1); i++) 
    {
        for (int j = 0; j < (myList->getSize() - i - 1); j++) 
        {
            int thisNum = myList->get(j).getNum() / 10;
            int nextNum = myList->get(j+1).getNum() / 10;
            if (thisNum < nextNum) 
            {
                objPos temp = myList->get(j);
                myList->set(myList->get(j + 1), j);
                myList->set(temp, j + 1);
            }
        }
    } 
}


void objPosStack::populateRandomElements(int size)
{
    // This function generates the number of randomly generated objPos instances with uninitialized
    //  x-y coordinate on the Stack, then sort them in ascending order using the digit of 10
    //  of the **number** field in objPos instances.

    // Implementation done.  You'd have to implement the following two private helper functions above.
    srand(time(NULL));
    generateObjects(size);
    sortByTenScoreBS();
}



void objPosStack::push(const objPos &thisPos) const
{
    myList->insertTail(thisPos);
    // Push thisPos on to the Stack.
    //  Think about which objPosDLinkedList method can realize this operation.
}

objPos objPosStack::pop()
{
    if (myList->isEmpty())
    {
        return objPos(-99, 0, 0, 0, 0);
    }
    else
    {
        return myList->removeTail();
    }
    // Pop the top element of the Stack.
    //  If the Stack is empty, return objPos(-99, 0, 0, 0, 0)
    //  Think about which objPosDLinkedList methods can realize this operation.
}

objPos objPosStack::top()
{
    if (myList->isEmpty())
    {
        return objPos(-99, 0, 0, 0, 0);
    }
    else
    {
        return myList->getTail();
    }
    // Return the top element of the Stack without removing it
    //  If the Stack is empty, return objPos(-99, 0, 0, 0, 0)
    //  Think about which objPosDLinkedList methods can realize this operation.
}

int objPosStack::size()
{
    // Return the size of the Stack 
    //  Think about which objPosDLinkedList method can realize this operation.
    return myList->getSize();
}

void objPosStack::printMe()
{
    // NOT GRADED
    //  Print the contents of the Stack
    //  Think about which objPosDLinkedList method can partially realize this operation.

    // IMPORTANT: USE THIS METHOD FOR DEBUGGING!!!
}
