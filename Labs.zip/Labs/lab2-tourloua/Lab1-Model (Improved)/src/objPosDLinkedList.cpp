#include "objPosDLinkedList.h"
#include <iostream>
using namespace std;

// Develop the objPos Doubly Linked List here.  
// Use the Test cases Test.cpp to complete the Test-Driven Development

objPosDLinkedList::objPosDLinkedList()
{   listHead= new DNode();
    listTail= new DNode();
    listHead->next=listTail;
    listTail->prev=listHead;
    listHead->prev=nullptr;
    listTail->next=nullptr;
    persistHead=listHead;
    listSize=0;
}

objPosDLinkedList::~objPosDLinkedList()
{
    if (listSize>0)
    {
        persistHead=listHead->next;
        while(persistHead->next!=listTail)
        {
            persistHead->prev=persistHead->next->prev;
            persistHead->next=persistHead->next->next;
            delete persistHead->prev;
        }
    }
    delete listHead;
    delete listTail;
    listHead=NULL;
    listTail=NULL;
    persistHead=NULL;
    listSize=0;
}

int objPosDLinkedList::getSize()
{
    return listSize;
}

bool objPosDLinkedList::isEmpty()
{
   int truth=getSize();
   if (truth==0)
   {
    return true;
   }
   else
   {
    return false;
   }  
}

void objPosDLinkedList::insertHead(const objPos &thisPos)
{
    listSize++;
    DNode* NewHead= new DNode();
    NewHead->data=thisPos;
    NewHead->next=listHead->next;
    NewHead->next->prev=NewHead;
    listHead->next=NewHead;
    NewHead->prev=listHead;

}

void objPosDLinkedList::insertTail(const objPos &thisPos)
{
    listSize++;
    DNode* NewTail= new DNode();
    NewTail->data=thisPos;
    NewTail->prev=listTail->prev;
    NewTail->prev->next=NewTail;
    listTail->prev=NewTail;
    NewTail->next=listTail;
}

void objPosDLinkedList::insert(const objPos &thisPos, int index)
{
    if (index<1)
    {
        insertHead(thisPos);
    }
    else
    {
        if(index>(listSize-2))
        {
            insertTail(thisPos);
        }
        else
        {
            listSize++;
            int i=0;
            persistHead->next=listHead->next->next;
            persistHead->prev=listHead;//persist head is at index zero
            while(i<index)
            {
                i++;
                persistHead->next=persistHead->next->next;
                persistHead->prev=persistHead->prev->next;              
            }
            DNode* NewIndex= new DNode();
            NewIndex->next=persistHead->next->prev;
            NewIndex->prev=persistHead->prev;
            NewIndex->prev->next=NewIndex;
            NewIndex->next->prev=NewIndex;

        }
    }

}

objPos objPosDLinkedList::getHead() const
{
    if(listSize==0)
    {
        return objPos{-99,0,0,0,0};
    }
    else
    {
        return listHead->next->data;
    }
}

objPos objPosDLinkedList::getTail() const
{
    if(listSize==0)
    {
        return objPos{-99,0,0,0,0};
    }
    else
    {
        return listTail->prev->data;
    }
}

objPos objPosDLinkedList::get(int index) const
{
    if (index <1)
    {
        return getHead();
    }
    else
    {
        if(index>(listSize-2))
        {
            return getTail();
        }
        else
        {
            int i=0;

            DNode* thisNode=listHead->next;
            while(i<index)
            {
                i++;
                thisNode=thisNode->next;
            }
            return thisNode->data;
        }
    }
}

objPos objPosDLinkedList::getNext()
{
    if(persistHead->next==nullptr)
    {
        return objPos{-99,0,0,0,0}; 
    }
    else
    {
        persistHead=persistHead->next;
        return persistHead->data;
    }
}

void objPosDLinkedList::resetReadPos()
{
    persistHead=listHead;
}

void objPosDLinkedList::set(const objPos &thisPos, int index)
{
    if (index < 0) 
    {
        index = 0;
    } 
    else if (index > (listSize-1)) 
    {
        index = listSize - 1;
    }

    DNode* thisNode=listHead->next;//we need a new DNode since persistHead only points to values and cannot change them
    //so while persistHead CAN delete and read values, it cannot make any lasting changes to them
    //kinda how like you can't change two pointers in a function unless you pass them in by reference I think...
    int i=0;
    while(i<index)
    {
        i++;
        thisNode=thisNode->next;
    }
    
    thisNode->data=thisPos;
    
}


objPos objPosDLinkedList::removeHead()
{
    if (listSize<1)
    {
        return objPos(-99,0,0,0,0);
    }
    else
    {
        DNode* thisNode=listHead->next;//captures the data we want
        listHead->next=listHead->next->next;
        delete listHead->next->prev;
        listHead->next->prev=listHead;
        listSize--;
        return thisNode->data;
    }
}

objPos objPosDLinkedList::removeTail()
{
    if (listSize<1)
    {
        return objPos(-99,0,0,0,0);
    }
    else
    {
        DNode* thisNode=listTail->prev;//captures the data we want
        listTail->prev=listTail->prev->prev;
        delete listTail->prev->next;
        listTail->prev->next=listTail;
        listSize--;
        return thisNode->data;
    }
}

objPos objPosDLinkedList::remove(int index)
{

    objPos ThisPos;
    if (listSize==0)
    {
        return objPos(-99,0,0,0,0);
    }
    if (index<1)
    {
        return removeHead();
    }
    if (index>listSize-2)
    {
        return removeTail();
    }
    else
        {   
            DNode* thisNode= listHead->next;
            int i=0;
            while(i<index)
            {
                i++;
                thisNode= thisNode->next;
            }
            thisNode->prev->next=thisNode->next;
            thisNode->next->prev=thisNode->prev;
            listSize--;
            objPos data=thisNode->data;
            delete thisNode;
            return data;
        }   
}


void objPosDLinkedList::printList() const
{/*
    DNode* temp = listHead;
    cout << "Dummy Header (Address: " << temp << ")"<<endl;
    int i = 1;
    while (temp->next != nullptr)
    {
        temp = temp->next;
        cout << "Element " << i << "(Address: "<<temp<< ")"<<endl;
        cout << "Data: " << (temp->data).getX() << ", " <<(temp->data).getY()<< ", " << (temp->data).getNum() << ", " << (temp->data).getPF() << ", " << (temp->data).getSym() << endl;
        cout << "Next: "<<temp->next<<endl;
        cout << "Prev: "<<temp->prev<<endl;
        i++;
    }
    cout << "Dummy Tail (Address: "<<temp<<")"<<endl;*/
}