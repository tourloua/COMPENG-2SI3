#include "objPosDLinkedList.h"
#include <iostream>
using namespace std;

// Develop the objPos Doubly Linked List here.  
// Use the Test cases Test.cpp to complete the Test-Driven Development

objPosDLinkedList::objPosDLinkedList()
{

}

objPosDLinkedList::~objPosDLinkedList()
{

}

int objPosDLinkedList::getSize()
{

}

bool objPosDLinkedList::isEmpty()
{
   
}

void objPosDLinkedList::insertHead(const objPos &thisPos)
{
    
}

void objPosDLinkedList::insertTail(const objPos &thisPos)
{
    
}

void objPosDLinkedList::insert(const objPos &thisPos, int index)
{
    
}

objPos objPosDLinkedList::getHead() const
{

}

objPos objPosDLinkedList::getTail() const
{

}

objPos objPosDLinkedList::get(int index) const
{

}

objPos objPosDLinkedList::getNext()
{

}

void objPosDLinkedList::resetReadPos()
{

}

void objPosDLinkedList::set(const objPos &thisPos, int index)
{

}


objPos objPosDLinkedList::removeHead()
{

}

objPos objPosDLinkedList::removeTail()
{
  
}

objPos objPosDLinkedList::remove(int index)
{

}


void objPosDLinkedList::printList() const
{

}


